
# Mi País RD - API de Loterías Dominicanas

Este repositorio publica automáticamente los últimos sorteos de las loterías dominicanas en formato JSON.

## 🚀 Uso
- Endpoint JSON (raw):  
  `https://raw.githubusercontent.com/rodydiaz/mipaisrd-loterias-api/main/public/data.json`

- GitHub Pages (si está activado):  
  `https://rodydiaz.github.io/mipaisrd-loterias-api/data.json`

- CDN jsDelivr:  
  `https://cdn.jsdelivr.net/gh/rodydiaz/mipaisrd-loterias-api@main/public/data.json`

## ⚙️ Cómo funciona
1. GitHub Actions corre cada 15 minutos.  
2. El scraper (`scraper/scraper.py`) extrae los datos desde la página de loterías.  
3. El JSON actualizado se guarda en `public/data.json` y se publica automáticamente.

## 📦 Configuración
- Se puede cambiar la fuente en `scraper.py` o agregando un secreto `SOURCE_URL`.

---

Hecho para **Mi País RD** 🇩🇴
